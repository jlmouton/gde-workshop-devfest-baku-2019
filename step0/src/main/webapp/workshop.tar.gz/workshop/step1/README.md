# MVP Product Landing Page - Step 1

An App Engine Standard demo app using Java 8, Maven, and Objectify.

Step 1: just the base Hello World project

## Running Locally

1. `mvn clean package`
2. `mvn appengine:run`

## Deploying

1. `mvn appengine:deploy`
