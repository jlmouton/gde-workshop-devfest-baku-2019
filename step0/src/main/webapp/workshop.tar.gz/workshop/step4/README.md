# MVP Product Landing Page - Step 4

An App Engine Standard demo app using Java 8, Maven, and Objectify.

Step 4: It is time to extract the list of interested beta testers.
We will create a servlet to dump the list of subscriber email addresses.

## Running Locally

1. `mvn clean package`
2. `mvn appengine:run`

## Deploying

1. `mvn appengine:deploy`